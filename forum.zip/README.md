# serverstudy
📶node.js로 서버 만들기

- DB : MongoDB
- express

# 실행
```
nodemon server.js
```

## .env
```
PORT = 8080
DB_URL="mongodb+srv://minji:minji0219@cluster0.lyybb93.mongodb.net/?retryWrites=true&w=majority"
```
